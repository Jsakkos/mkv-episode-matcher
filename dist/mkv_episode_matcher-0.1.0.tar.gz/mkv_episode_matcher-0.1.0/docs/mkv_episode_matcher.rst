mkv\_episode\_matcher package
=============================

Submodules
----------

mkv\_episode\_matcher.config module
-----------------------------------

.. automodule:: mkv_episode_matcher.config
   :members:
   :undoc-members:
   :show-inheritance:

mkv\_episode\_matcher.episode\_matcher module
---------------------------------------------

.. automodule:: mkv_episode_matcher.episode_matcher
   :members:
   :undoc-members:
   :show-inheritance:

mkv\_episode\_matcher.mkv\_to\_srt module
-----------------------------------------

.. automodule:: mkv_episode_matcher.mkv_to_srt
   :members:
   :undoc-members:
   :show-inheritance:

mkv\_episode\_matcher.tmdb\_client module
-----------------------------------------

.. automodule:: mkv_episode_matcher.tmdb_client
   :members:
   :undoc-members:
   :show-inheritance:

mkv\_episode\_matcher.utils module
----------------------------------

.. automodule:: mkv_episode_matcher.utils
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: mkv_episode_matcher
   :members:
   :undoc-members:
   :show-inheritance:
